$('.ui.dropdown')
    .dropdown();

function myFunction() {
    var x = document.getElementById("myLinks");
    if (x.style.display === "flex") {
        x.style.display = "none ";
    } else {
        x.style.display = "flex";
    }
}