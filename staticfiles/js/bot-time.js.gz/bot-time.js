$('#example5').progress();
$('#example4').progress();
$('#example3').progress();
$('#example2').progress();
$('#example1').progress();

